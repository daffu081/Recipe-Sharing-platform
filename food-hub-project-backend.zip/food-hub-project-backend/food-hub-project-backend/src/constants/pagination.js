export const queryFields = [
  'page',
  'limit',
  'sortBy',
  'sortOrder',

]
export const RecipeFilterableFields = ['searchTerm', 'category', 'country']
