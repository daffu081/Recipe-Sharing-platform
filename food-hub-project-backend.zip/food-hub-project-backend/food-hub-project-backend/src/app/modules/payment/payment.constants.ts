export const paymentFilterableFields: string[] = [
  'searchTerm',
  'id',
  'transactionId',
  'studentId',
  'status',
];

export const paymentSearchableFields: string[] = [
  'transactionId',
  'studentId',
  'status',
];
